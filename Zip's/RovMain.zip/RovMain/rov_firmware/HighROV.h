#pragma once


namespace HighROV
{
    void init();
    void run();
};

