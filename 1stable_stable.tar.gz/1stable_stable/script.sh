#!/usr/bin/bash

gst-launch-1.0 \
    rtspsrc location="rtsp://root:12345@192.168.1.6/stream=0" latency=0 ! \
    rtph264depay ! \
    avdec_h264 ! \
    videoconvert ! \
    textoverlay name=overlay \
        text="Temp: \nRegulators: \nPump: " \
        valignment=top \
        halignment=left \
        font-desc="Sans, 12" \
        xpad=15 \
        ypad=15 \
        color=0xFFFFFFFF \
        shaded-background=true ! \
    autovideosink sync=false &

if ! command -v xclip &> /dev/null; then
    echo "Ошибка: xclip не установлен. Установите его командой:"
    echo "sudo apt-get install xclip"
    exit 1
fi

previous_text=""

while true; do
    current_text=$(xclip -out -selection clipboard 2>/dev/null)
    
    if [[ -n "$current_text" && "$current_text" != "$previous_text" ]]; then
        echo "Обновление текста: $current_text"
        
        # Разбираем данные (ожидаем формат "temp;regulators;pump")
        IFS=';' read -r TEMP REGULATORS PUMP <<< "$current_text"
        
        TEXT="Temp: ${TEMP}\nRegulators: ${REGULATORS}\nPump: ${PUMP}"
        
        echo "Установка текста: $TEXT"
        # Альтернативный подход - использовать gst-inspect-1.0 и gst-launch для динамического обновления
        # В реальности для динамического обновления нужен более сложный подход
        
        previous_text="$current_text"
    fi
    
    sleep 1
done