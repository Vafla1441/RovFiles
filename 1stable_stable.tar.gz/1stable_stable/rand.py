import random
import pyperclip
import time

for i in range(100):
	random_number = ''.join([str(random.randint(0, 9)) for _ in range(2)]) + ';' + \
		''.join([str(random.randint(0, 9)) for _ in range(2)]) + ';' + ''.join([str(random.randint(0, 9)) for _ in range(2)])
	pyperclip.copy(random_number)
	print(f"Сгенерировано и скопировано в буфер: {random_number}")
	time.sleep(1)