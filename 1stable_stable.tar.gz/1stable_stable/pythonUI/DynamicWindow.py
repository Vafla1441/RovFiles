import tkinter as tk

class DynamicWindow:
    def __init__(self, parent):
        self.top = tk.Toplevel(parent)
        self.top.title("Оверлейм")
        self.top.geometry("200x180")
        
        self.varReg = tk.StringVar(value=f"Reg: ")
        self.varTemp = tk.StringVar(value=f"Temp: ")
        self.varNasos = tk.StringVar(value=f"Nasos: ")
        
        label_nasos = tk.Label(self.top, textvariable=self.varNasos, font=("Arial", 14))
        label_nasos.pack()

        label_reg = tk.Label(self.top, textvariable=self.varReg, font=("Arial", 14))
        label_reg.pack(pady=20)
        
        label_temp = tk.Label(self.top, textvariable=self.varTemp, font=("Arial", 14))
        label_temp.pack(pady=10)

    def update(self, reg_value, temp_value, nasos_value):
        self.varReg.set(f"Reg: {reg_value}")
        self.varTemp.set(f"Temp: {temp_value:.1f}°C")
        self.varNasos.set(f"Nasos: {nasos_value:.1f}")
