#!/usr/bin/env python3
import os

fifo_path = "/tmp/overlay_fifo"

if not os.path.exists(fifo_path):
    os.mkfifo(fifo_path)

while True:
    text = input("Введите текст для оверлея: ")
    with open(fifo_path, "w") as fifo:
        fifo.write(text + "\n")