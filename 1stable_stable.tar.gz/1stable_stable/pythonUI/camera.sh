#!/usr/bin/bash

# Очищаем старый FIFO, если он есть
rm -f /tmp/overlay_fifo
mkfifo /tmp/overlay_fifo

# Запускаем GStreamer с динамическим текстом из FIFO
gst-launch-1.0 -e \
    rtspsrc location="rtsp://root:12345@192.168.1.6/stream=0" latency=0 ! \
    rtph264depay ! avdec_h264 ! videoconvert ! \
    textoverlay name=overlay text="Initial Text" valignment=top halignment=left font-desc="Sans, 24" ! \
    videoconvert ! autovideosink sync=false &

# Обновляем оверлей из FIFO
while true; do
    if read -r new_text < /tmp/overlay_fifo; then
        echo "Обновление оверлея: $new_text"
        gst-launch-1.0 --gst-plugin-load=libgstdebugutils.so \ 
            gst-inspect-1.0 textoverlay
        gst-launch-1.0 --gst-plugin-load=libgstdebugutils.so \
            gst-inspect-1.0 overlay
        # Отправляем новое значение в textoverlay
        gst-launch-1.0 -q \
            videotestsrc num-buffers=1 ! \
            textoverlay name=overlay text="$new_text" ! \
            fakesink
    fi
done