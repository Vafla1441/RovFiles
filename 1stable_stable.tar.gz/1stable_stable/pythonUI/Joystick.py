import pygame
import json
import time

class Joystick:
    def __init__(self, add_log):
        self.log = add_log

        pygame.init()
        pygame.joystick.init()

        self.is_joystick = True
        self.flag_pump = False
        self.timer_pump = 0
        self.timer_reg = 0

        self.mappings = {
            "axis_x": 0,
            "axis_y": 0,
            "axis_z": 0,
            "axis_w": 0,
            "axis_pump": 0,
            "manipulator_rotation": 0,
            "camera_rotation": 0,
            "camera_rotation2": 0,
            "manipulator_open": 0,
            "manipulator_close": 0,
            "twenty_power": 0,
            "fifty_power": 0,
            "pump": 0,
            "laser": 0,
            "stop_polnagr": 0,
            "cruise_engines_up": 0,
            "cruise_engines_down": 0,
            "regulators": 0, 
            "kp_press": 31,
            "kp_up": 34,
            "kp_down": 35,  
            "kd_press": 38,
            "kd_up": 36,
            "kd_down": 37,
            "upper": 0
        }
        self.values = {
            "axis_x": 0,
            "axis_y": 0,
            "axis_z": 0,
            "axis_w": 0,
            "axis_t": 0,
            "axis_pump": 0,
            "manipulator_rotation": 0,
            "camera_rotation": [0, 0, 0],
            "scale_power": 1.0,
            "manipulator_open_close": 0,
            "pump_laser": 0,
            "regulators": 0,
            "desired_depth": 0,
            "kp": 4,
            "kd": 1,
            "upper": 0
        }

        if pygame.joystick.get_count() == 0:
            self.is_joystick = False
            self.log("Не обнаружено джойстика!", "ERROR")
            self.update_buttons()
            return

        self.joystick = pygame.joystick.Joystick(0)
        self.joystick.init()
        self.update_buttons()

    def update_buttons(self):
        try:
            with open("Joystick.settings", "r") as f:
                self.mappings = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.log("Невозможно загрузить настройки джойстика", "ERROR")

    def clamp(self, value, min_val, max_val):
        return max(min_val, min(value, max_val))

    def update(self):
        if not self.is_joystick:
            return 
        pygame.event.pump() 

        self.values['axis_x'] = self.joystick.get_axis(self.mappings['axis_x'])
        self.values['axis_y'] = self.joystick.get_axis(self.mappings['axis_y'])
        self.values['axis_t'] = self.joystick.get_axis(self.mappings['axis_z']) 
        self.values['axis_w'] = self.joystick.get_axis(self.mappings['axis_w'])

        if self.flag_pump:
            self.values['axis_pump'] = self.joystick.get_axis(self.mappings['axis_pump'])
        else:
            self.values['axis_pump'] = -1
        
        # self.values['desired_depth'] -= self.values['axis_w'] * 0.01
        # self.values['desired_depth'] = self.clamp(self.values['desired_depth'] , 0.0, 2.0)

        self.values['camera_rotation'][1] = self.joystick.get_axis(self.mappings['camera_rotation2'])
        
        if   0.8 < self.values['axis_x']:
            self.values["axis_z"] = 1
        elif self.values['axis_x'] < -0.8:
            self.values["axis_z"] = -1
        else:
            self.values["axis_z"] = 0


        for event in pygame.event.get():
            if event.type == pygame.JOYHATMOTION:
                hat_x, hat_y = event.value
                self.values['manipulator_rotation'] = -hat_x
                self.values['camera_rotation'][0] = -hat_y
                # self.log(self.values['camera_rotation'][0], self.values['camera_rotation'][1])

        power_buttons_pressed = False
        manipulator_buttons_pressed = False
        cruise_engines_pressed = False
        upper_pressed = False
        button_actions = [
            "manipulator_open", "manipulator_close", 
            "pump", "laser", "stop_polnagr", 
            "twenty_power", "fifty_power", 
            "cruise_engines_up", "cruise_engines_down",
            "regulators", "kp_up", "kp_down", "kd_up", "kd_down",
            "upper"
        ]


        for action in button_actions:
            button_id = self.mappings[action]
            if self.joystick.get_button(button_id):
                self._handle_button_press(action)
                if action in ("twenty_power", "fifty_power"):
                    power_buttons_pressed = True
                if action in ("manipulator_open", "manipulator_close"):
                    manipulator_buttons_pressed = True
                if action in ("upper"):
                    upper_pressed = True

        if not power_buttons_pressed:
            self.values["scale_power"] = 1.0

        if not manipulator_buttons_pressed:
            self.values["manipulator_open_close"] = 0

        if not upper_pressed:
            self.values["upper"] = 0

        print(self.values)
    def _handle_button_press(self, button_name):

        if button_name == "manipulator_close":
            self.values["manipulator_open_close"] = -1
        elif button_name == "manipulator_open":
            self.values["manipulator_open_close"] = 1

        if button_name == "stop_polnagr":
            self.values["pump_laser"] = 0
            self.values["regulators"] = 0
            # self.values['camera_rotation'][1] = 0
            self.log("Регуляторы выкл")
        elif button_name == "pump" and self.timer_pump + 0.5 < time.time():
            self.flag_pump = not self.flag_pump
            self.timer_pump = time.time()
            self.log("Насос качает")
        elif button_name == "laser":
            self.values["pump_laser"] = 2
            self.log("Лазер вкл")

        if button_name == "twenty_power":
            self.values["scale_power"] = 0.25
            self.log("Мощность двигателей установлена в 25%")
        elif button_name == "fifty_power":
            self.values["scale_power"] = 0.5
            self.log("Мощность двигателей установлена в 50%")

        if button_name == "upper":
            self.values["upper"] = 1
        # elif button_name == "cruise_engines_down":
        #     self.values["axis_t"] = -1

        if button_name == "regulators" and self.timer_reg + 0.5 < time.time():
            self.timer_reg = time.time()
            self.values["regulators"] = not self.values["regulators"]
            self.log("Регуляторы вкл/выкл")

        if button_name == "kp_up":
            self.values["kp"] += 1
        elif button_name == "kp_down":
            self.values["kp"] -= 1

        if button_name == "kd_up":
            self.values["kd"] += 1
        elif button_name == "kp_down":
            self.values["kd"] -= 1