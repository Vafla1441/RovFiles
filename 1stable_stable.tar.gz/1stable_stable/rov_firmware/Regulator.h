#pragma once
#include <Arduino.h>

class Regulator {
public:
  double apply(double error, double p, double i, double d);
  double calc_p_part(double p);
  double calc_i_part(double i);
  double calc_d_part(double d);
  double clamp(double value, double min_value, double max_double);
private:
  unsigned long m_last_timestamp = 0;
  unsigned long m_curr_timestamp = 0;
  unsigned long m_dt = 0;
  double m_last_error = 0;
  double m_curr_error = 0;
  double m_integral = 0;
};