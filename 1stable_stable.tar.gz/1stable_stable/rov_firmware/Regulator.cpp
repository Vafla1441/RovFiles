#include "Regulator.h"

double Regulator::apply(double error, double p, double i, double d) {
  m_last_timestamp = m_curr_timestamp;
  m_curr_timestamp = millis();
  m_dt = (m_curr_timestamp - m_last_timestamp);
  m_last_error = m_curr_error;
  m_curr_error = error;

  const double pu = calc_p_part(p);
  const double iu = calc_i_part(i);
  const double du = calc_d_part(d);

  return pu + du;
}

double Regulator::calc_p_part(double p) {
  return p * m_curr_error;
}
double Regulator::calc_i_part(double i) {
  m_integral += m_curr_error * m_dt;
  static const double max_integral = 100.0;
  m_integral = clamp(m_integral, -max_integral, max_integral);
  return i * m_integral;
}
double Regulator::calc_d_part(double d) {
  double differential_part = d * (m_curr_error - m_last_error) / m_dt;
  return differential_part;
}
double Regulator::clamp(double value, double min_value, double max_value) {
  if (value < min_value) {
    return min_value;
  }
  if (max_value < value) {
    return max_value;
  }
  return value;
}