#pragma once
class RovMagics
{
public:
    static void init();
    static void pow(int powpow);
};

