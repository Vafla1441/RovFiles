#include "HighROV.h"
#include "PWMController.h"
#include "Networking.h"
#include "Data.h"
#include "Thrusters.h"
#include "RotaryCameras.h"
#include "DepthSensor.h"
#include "Manipulator.h"
#include "Config.h"
#include "IMUSensor.h"
#include "USB/USBAPI.h"
#include "AnalogSensors.h"
#include "RovMagics.h"
#include "Regulator.h"

rov::RovControl control;
rov::RovTelimetry telimetry;

void HighROV::init() {
    //SerialUSB.println("HighROV init!");

    pinMode(LED_BUILTIN, OUTPUT);
    analogWrite(LED_BUILTIN, 100);

    PWMController::init();
    Networking::init();
    Thrusters::init();
    RotaryCameras::init();
    DepthSensor::init();
    Manipulator::init();
    IMUSensor::init();
    AnalogSensors::init();
    RovMagics::init();

    delay(3000);
}

void debug(rov::RovControl &ctrl) {
    using namespace config;

    PWMController::set_thruster(thrusters::horizontal_front_left,  ctrl.thrusterPower[0]);
    PWMController::set_thruster(thrusters::horizontal_front_right, ctrl.thrusterPower[1]);
    PWMController::set_thruster(thrusters::horizontal_back_left,   ctrl.thrusterPower[2]);
    PWMController::set_thruster(thrusters::horizontal_back_right,  ctrl.thrusterPower[3]);
    PWMController::set_thruster(thrusters::vertical_front,         ctrl.thrusterPower[4]);
    PWMController::set_thruster(thrusters::vertical_back,          ctrl.thrusterPower[5]);

    PWMController::set_servo_power(servos::front,  ctrl.thrusterPower[6]);
    PWMController::set_servo_power(servos::back,   ctrl.thrusterPower[7]);
    PWMController::set_servo_power(servos::pwm_a2, ctrl.thrusterPower[8]);
    PWMController::set_servo_power(servos::pwm_a3, ctrl.thrusterPower[9]);
}

void HighROV::run() {
    AnalogSensors::update();

    static Regulator diff_reg;
    telimetry.yaw = IMUSensor::getYaw();
    telimetry.roll = -IMUSensor::getRoll();
    telimetry.pitch = IMUSensor::getPitch();
    telimetry.depth = DepthSensor::getDepth();
    telimetry.temperature = DepthSensor::getTemp();
    telimetry.ammeter = AnalogSensors::getAmperage();
    telimetry.voltmeter = AnalogSensors::getVoltage();
    telimetry.cameraIndex = RotaryCameras::get_cam_index();
    Networking::read_write_udp(telimetry, control);
    if(control.desiredDepth == 1) {
      control.regulators = 1;
    }
    if (control.regulators == 1) {
        float current_pitch = telimetry.roll; 
        float desired_pitch = 92.4;
        float kp = control.kp;
        float kd = control.kd;
        if(control.desiredDepth == 1) {
          desired_pitch = 130;
        }
        double e = (desired_pitch - current_pitch);

        rov::RovControl calculatedControl = control;
        double u = diff_reg.apply(e, kp, 0, kd);

        // SerialUSB.print("Desired: "); SerialUSB.print(desired_pitch); SerialUSB.print("\t");
        // SerialUSB.print("Current: "); SerialUSB.print(current_pitch); SerialUSB.print("\t");
        // SerialUSB.print("e: "); SerialUSB.print(e); SerialUSB.print("\t");
        // SerialUSB.print("kp: "); SerialUSB.print(kp); SerialUSB.print("\t");
        // SerialUSB.print("axisT: "); SerialUSB.print(control.axisX); SerialUSB.print("\t");
        // SerialUSB.print("U: "); SerialUSB.print(u); SerialUSB.print("\t");
        // SerialUSB.println(" ");
        calculatedControl.axisR = constrain(control.axisT - u, -100, 100);

        Thrusters::update_thrusters(calculatedControl, telimetry);
        RotaryCameras::set_angle(config::servos::front, constrain(control.cameraRotation[0], -1, 1) * 3.0);
        RotaryCameras::set_angle(config::servos::back,  constrain(control.cameraRotation[1], -1, 1) * 3.0);
        RotaryCameras::select_cam(control.cameraIndex == 1 ? true : false);
        Manipulator::set_power(control.manipulatorRotation, control.manipulatorOpenClose);
        RovMagics::pow(control.axisV);
    }
    else if (!control.debugFlag) {
        control.axisR = control.axisT;

        Thrusters::update_thrusters(control, telimetry);
        RotaryCameras::set_angle(config::servos::front, constrain(control.cameraRotation[0], -1, 1) * 3.0);
        RotaryCameras::set_angle(config::servos::back,  constrain(control.cameraRotation[1], -1, 1) * 3.0);
        RotaryCameras::select_cam(control.cameraIndex == 1 ? true : false);
        Manipulator::set_power(control.manipulatorRotation, control.manipulatorOpenClose);
        RovMagics::pow(control.axisV);
    } else {
        debug(control);
    }
    if (DepthSensor::getUpdateStatus() == true) {
        analogWrite(LED_BUILTIN, sin(millis() * 0.01) * 127 + 127);
    } else {
        analogWrite(LED_BUILTIN, 255);
    }
}

