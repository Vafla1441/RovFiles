#include "RovMagics.h"
#include "Config.h"
#include "PWMController.h"

void RovMagics::init() {
    using namespace config;
}

void RovMagics::pow(int powpow) {
    using namespace config;
    PWMController::set_servo_power(config::servos::pwm_a2, powpow);
}