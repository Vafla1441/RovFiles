#pragma once

#include <QtCore>

qint16 calculateCRC(const char* data, const size_t len);
